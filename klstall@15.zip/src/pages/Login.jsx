// src/Login.jsx
import { useState } from "react"
import { useNavigate } from "react-router-dom"
import { supabase } from "../lib/supabase"
import { motion } from "framer-motion"

export default function Login() {
  const navigate = useNavigate()
  const [email, setEmail] = useState("")
  const [password, setPassword] = useState("")
  const [error, setError] = useState("")
  const [loading, setLoading] = useState(false)

  const handleLogin = async (e) => {
    e.preventDefault()
    setLoading(true)
    setError("")

    const { error } = await supabase.auth.signInWithPassword({
      email,
      password,
    })

    if (error) setError(error.message)
    else navigate("/dashboard")
    setLoading(false)
  }

  return (
    <div className="fixed inset-0 h-screen w-screen flex items-center justify-center bg-gradient-to-br from-red-700 via-yellow-400 to-white overflow-hidden">
      {/* Animated Gradient Blobs */}
      <motion.div
        animate={{ scale: [1, 1.2, 1] }}
        transition={{ repeat: Infinity, duration: 6 }}
        className="absolute w-[30rem] h-[30rem] bg-yellow-300 rounded-full mix-blend-multiply filter blur-3xl opacity-40 top-10 left-0"
      />
      <motion.div
        animate={{ scale: [1.1, 0.9, 1.1] }}
        transition={{ repeat: Infinity, duration: 8 }}
        className="absolute w-[28rem] h-[28rem] bg-red-500 rounded-full mix-blend-multiply filter blur-3xl opacity-40 bottom-10 right-0"
      />

      {/* Floating Sparkles */}
      {Array.from({ length: 15 }).map((_, i) => (
        <motion.div
          key={i}
          className="absolute w-1 h-1 bg-white rounded-full shadow-md"
          initial={{ x: Math.random() * window.innerWidth, y: Math.random() * window.innerHeight }}
          animate={{ y: [null, -20], opacity: [1, 0] }}
          transition={{
            duration: Math.random() * 5 + 4,
            repeat: Infinity,
            delay: Math.random() * 5,
          }}
        />
      ))}

      {/* Content */}
      <motion.div
        initial={{ opacity: 0, y: 40 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.8 }}
        className="relative z-10 w-full h-full flex flex-col justify-center items-center bg-white/10 backdrop-blur-md border-t border-white/20 p-6 rounded-2xl"
      >
        {/* Logo */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.2 }}
          className="flex flex-col items-center mb-6"
        >
          <motion.img
            src="https://i.ibb.co/mVcdHGMP/IMG-20250917-214439-removebg-preview.png"
            alt="KL Stall Logo"
            className="w-32 h-32 mb-4 drop-shadow-[0_0_25px_rgba(255,255,255,0.7)]"
            animate={{ scale: [1, 1.05, 1] }}
            transition={{ repeat: Infinity, duration: 5 }}
          />
          <h1 className="text-4xl sm:text-5xl font-extrabold text-white tracking-wide text-center drop-shadow-[0_0_15px_rgba(255,255,255,0.8)]">
            KL Stall & Decors
          </h1>
        </motion.div>

        <h2 className="text-lg sm:text-xl md:text-2xl font-semibold text-white/90 text-center mb-6 drop-shadow-lg">
          ✨ Welcome Back! ✨
        </h2>

        {/* Form */}
        <form className="w-full max-w-md space-y-4">
          <motion.input
            whileFocus={{ scale: 1.02 }}
            type="email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            placeholder="Email Address"
            className="w-full p-3 rounded-lg bg-white/30 text-red-900 placeholder-red-200 focus:outline-none focus:ring-2 focus:ring-yellow-400"
            required
          />
          <motion.input
            whileFocus={{ scale: 1.02 }}
            type="password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            placeholder="Password"
            className="w-full p-3 rounded-lg bg-white/30 text-red-900 placeholder-red-200 focus:outline-none focus:ring-2 focus:ring-yellow-400"
            required
          />
          {error && <p className="text-red-600 text-sm font-medium">{error}</p>}

          <motion.button
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            onClick={handleLogin}
            disabled={loading}
            className="w-full bg-gradient-to-r from-red-600 via-yellow-400 to-white text-red-900 font-bold p-3 rounded-lg shadow-lg hover:opacity-90 transition-all"
          >
            {loading ? "Logging in..." : "Login 🎉"}
          </motion.button>
        </form>

        {/* Links */}
        <div className="flex justify-between items-center mt-6 text-sm w-full max-w-md px-6 flex-wrap gap-2">
          <button
            onClick={() => navigate("/signup")}
            className="text-white/70 hover:text-yellow-300 transition"
          >
            Create an account
          </button>
          <button
            onClick={() => navigate("/reset-password")}
            className="text-white/70 hover:text-yellow-300 transition"
          >
            Forgot password?
          </button>
        </div>
      </motion.div>
    </div>
  )
}
