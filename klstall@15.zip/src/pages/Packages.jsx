// src/pages/Packages.jsx
import React, { useEffect, useState } from "react";
import { supabase } from "../lib/supabase";
import { useCart } from "../contexts/CartContext";
import { useNavigate } from "react-router-dom";
import { motion } from "framer-motion";

export default function Packages() {
  const [packages, setPackages] = useState([]);
  const [filteredPackages, setFilteredPackages] = useState([]);
  const [searchQuery, setSearchQuery] = useState("");
  const [sortOption, setSortOption] = useState("");
  const [category, setCategory] = useState("All");
  const [cartPulse, setCartPulse] = useState(false);

  const { cart, addToCart } = useCart();
  const navigate = useNavigate();

  const categories = ["All", "Stall", "Decoration", "DJ", "Venue"];

  useEffect(() => {
    const fetchPackages = async () => {
      const { data, error } = await supabase.from("packages").select("*");
      if (error) {
        console.error("Error fetching packages:", error);
        return;
      }

      const packagesWithUrl = data.map(pkg => {
        if (pkg.image_url && !pkg.image_url.startsWith("http")) {
          const { publicUrl } = supabase.storage
            .from("package-images")
            .getPublicUrl(pkg.image_url);
          return { ...pkg, image_url: publicUrl };
        }
        return pkg;
      });

      setPackages(packagesWithUrl);
      setFilteredPackages(packagesWithUrl);
    };

    fetchPackages();
  }, []);

  useEffect(() => {
    let result = [...packages];
    if (category !== "All") result = result.filter(pkg => pkg.category === category);
    if (searchQuery) result = result.filter(pkg =>
      pkg.title.toLowerCase().includes(searchQuery.toLowerCase())
    );

    if (sortOption === "priceAsc") result.sort((a, b) => a.price - b.price);
    else if (sortOption === "priceDesc") result.sort((a, b) => b.price - a.price);
    else if (sortOption === "titleAsc") result.sort((a, b) => a.title.localeCompare(b.title));
    else if (sortOption === "titleDesc") result.sort((a, b) => b.title.localeCompare(a.title));

    setFilteredPackages(result);
  }, [searchQuery, sortOption, category, packages]);

  const handleAddToCart = (pkg) => {
    addToCart({ ...pkg, quantity: 1 });
    setCartPulse(true);
    setTimeout(() => setCartPulse(false), 300);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-red-700 via-yellow-400 to-white py-8 px-4 sm:px-6 md:px-8 lg:px-12 relative">
      <h1 className="text-3xl font-bold text-center text-red-900 mb-8">
        Our Packages
      </h1>

      {/* Categories */}
      <div className="flex justify-center flex-wrap gap-3 mb-6 max-w-screen-xl mx-auto">
        {categories.map(cat => (
          <button
            key={cat}
            onClick={() => setCategory(cat)}
            className={`px-4 py-2 rounded-full font-semibold transition ${
              category === cat
                ? "bg-red-600 text-white shadow-lg"
                : "bg-white text-red-900 border border-red-300 hover:bg-red-100"
            }`}
          >
            {cat}
          </button>
        ))}
      </div>

      {/* Search & Sort */}
      <div className="flex flex-col sm:flex-row sm:justify-between items-center gap-4 mb-6 max-w-screen-xl mx-auto">
        <input
          type="text"
          placeholder="Search packages..."
          value={searchQuery}
          onChange={e => setSearchQuery(e.target.value)}
          className="w-full sm:w-1/2 px-4 py-2 rounded-lg border border-red-300 focus:outline-none focus:ring-2 focus:ring-red-500"
        />
        <select
          value={sortOption}
          onChange={e => setSortOption(e.target.value)}
          className="w-full sm:w-1/3 px-4 py-2 rounded-lg border border-red-300 focus:outline-none focus:ring-2 focus:ring-red-500"
        >
          <option value="">Sort By</option>
          <option value="priceAsc">Price: Low → High</option>
          <option value="priceDesc">Price: High → Low</option>
          <option value="titleAsc">Title: A → Z</option>
          <option value="titleDesc">Title: Z → A</option>
        </select>
      </div>

      {/* Packages Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6 max-w-screen-xl mx-auto">
        {filteredPackages.length === 0 ? (
          <p className="text-center text-red-900 col-span-full">
            No packages found.
          </p>
        ) : (
          filteredPackages.map(pkg => (
            <motion.div
              key={pkg.id}
              whileHover={{ scale: 1.05 }}
              className="bg-white rounded-xl shadow-md p-4 flex flex-col justify-between"
            >
              <img
                src={pkg.image_url}
                alt={pkg.title}
                className="w-full h-40 object-cover rounded-lg mb-4"
              />
              <h2 className="text-xl font-semibold text-red-700 mb-2 break-words">
                {pkg.title}
              </h2>
              <p className="text-red-800 mb-4 break-words">{pkg.desc}</p>
              <p className="text-lg font-bold text-red-900 mb-4">₹ {pkg.price}</p>
              <motion.button
                whileTap={{ scale: 0.95 }}
                onClick={() => handleAddToCart(pkg)}
                className="bg-red-600 text-white px-4 py-2 rounded-full hover:bg-red-700 transition w-full"
              >
                Add to Cart
              </motion.button>
            </motion.div>
          ))
        )}
      </div>

      {/* Floating Cart Button */}
      {cart.length > 0 && (
        <motion.button
          onClick={() => navigate("/cart")}
          className={`fixed bottom-6 right-6 bg-yellow-400 text-red-900 flex items-center justify-center gap-2 px-5 py-3 rounded-full shadow-lg hover:bg-yellow-300 font-semibold ${cartPulse ? "animate-pulse" : ""}`}
          whileTap={{ scale: 0.95 }}
        >
          🛒 Cart
          <span className="bg-red-600 text-white text-sm px-2 py-1 rounded-full">
            {cart.length}
          </span>
        </motion.button>
      )}
    </div>
  );
}
