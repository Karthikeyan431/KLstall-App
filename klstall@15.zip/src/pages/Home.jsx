// src/pages/Home.jsx
import React from "react";
import { motion } from "framer-motion";
import { useNavigate } from "react-router-dom";

export default function Home() {
  const navigate = useNavigate();

  return (
    <div className="inset-0 min-h-screen bg-gradient-to-b from-red-700 via-yellow-500 to-white text-white animate-gradient">
      {/* Hero Section */}
      <section className="flex flex-col items-center justify-center text-center py-24 px-6">
        <motion.img
          src="https://i.ibb.co/FkYCyrW1/IMG-20250917-214439-removebg-preview.png"
          alt="KL Stall Logo"
          className="w-40 h-40 mb-6 drop-shadow-2xl"
          initial={{ scale: 0 }}
          animate={{ scale: 1 }}
          transition={{ duration: 1 }}
        />

        <motion.h1
          className="text-5xl font-extrabold mb-4 bg-gradient-to-r from-white to-yellow-300 bg-clip-text text-transparent drop-shadow-lg"
          initial={{ y: -20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 0.3, duration: 0.8 }}
        >
          KL Stall & Decors
        </motion.h1>

        <motion.p
          className="text-white/90 max-w-xl leading-relaxed text-lg font-light"
          initial={{ y: 10, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 0.6, duration: 0.8 }}
        >
          Your one-stop solution for <span className="text-yellow-200 font-semibold">event decorations</span>, buffet stalls, and complete event management.
          Adding <span className="text-white font-semibold">color & creativity</span> to every celebration 🎉
        </motion.p>

        <motion.div
          className="flex gap-4 mt-8 flex-wrap justify-center"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 1 }}
        >
          <button
            onClick={() => navigate("/packages")}
            className="bg-gradient-to-r from-red-600 to-yellow-500 px-6 py-3 rounded-full text-lg font-semibold text-white shadow-lg hover:scale-105 transition-all"
          >
            View Packages
          </button>
          <button
            onClick={() => navigate("/contact")}
            className="border-2 border-white px-6 py-3 rounded-full text-lg font-semibold text-white hover:bg-white hover:text-red-700 transition-all"
          >
            Contact Us
          </button>
        </motion.div>
      </section>

      {/* About Section */}
      <section className="text-center px-6 py-16 bg-white/10 backdrop-blur-md shadow-inner">
        <motion.h2
          className="text-3xl font-bold mb-4 bg-gradient-to-r from-yellow-300 to-white bg-clip-text text-transparent"
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          transition={{ duration: 0.6 }}
        >
          Why Choose Us?
        </motion.h2>

        <motion.p
          className="text-white/90 max-w-2xl mx-auto leading-relaxed text-lg"
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          transition={{ delay: 0.3, duration: 0.8 }}
        >
          At <span className="text-yellow-300 font-semibold">KL Stall & Decors</span>, we make your events unforgettable.
          From elegant weddings to vibrant college functions — we ensure <span className="text-white font-semibold">perfection in every detail</span>.
        </motion.p>

        <motion.div
          className="flex justify-center gap-8 mt-10 flex-wrap"
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          transition={{ delay: 0.5, duration: 0.8 }}
        >
          {[
            { title: "Creative Designs", text: "Unique, modern, and eye-catching decorations for every occasion." },
            { title: "Affordable Packages", text: "Custom plans that suit your budget perfectly." },
            { title: "Trusted Team", text: "Experienced professionals ensuring smooth and successful events." },
          ].map((item, index) => (
            <div
              key={index}
              className="bg-gradient-to-br from-red-600 to-yellow-500 p-6 rounded-2xl shadow-xl w-64 hover:scale-105 transition-transform"
            >
              <h3 className="text-xl font-bold mb-2 text-white">{item.title}</h3>
              <p className="text-white/90 text-sm">{item.text}</p>
            </div>
          ))}
        </motion.div>
      </section>
    </div>
  );
}
