// src/pages/AdminPage.jsx
import React, { useState } from "react";
import { supabase } from "../lib/supabase";
import { motion } from "framer-motion";

export default function AdminPage() {
  const [title, setTitle] = useState("");
  const [price, setPrice] = useState("");
  const [desc, setDesc] = useState("");
  const [file, setFile] = useState(null);
  const [category, setCategory] = useState("Stall");
  const [loading, setLoading] = useState(false);

  async function handleAdd(e) {
    e.preventDefault();
    setLoading(true);

    try {
      let imageUrl = null;

      if (file) {
        const fileName = `${Date.now()}_${file.name}`;
        const { error: uploadError } = await supabase.storage
          .from("package-images")
          .upload(fileName, file);

        if (uploadError) throw uploadError;

        const { data: publicData, error: urlError } = await supabase.storage
          .from("package-images")
          .getPublicUrl(fileName);

        if (urlError) throw urlError;

        imageUrl = publicData.publicUrl;
      }

      const { error: insertError } = await supabase.from("packages").insert([
        {
          title,
          description: desc,
          price,
          image_url: imageUrl,
          category,
          is_active: true,
        },
      ]);

      if (insertError) throw insertError;

      alert("✅ Package added successfully!");
      setTitle("");
      setDesc("");
      setPrice("");
      setFile(null);
      setCategory("Stall");
    } catch (err) {
      console.error("Error adding package:", err);
      alert("❌ Error: " + (err.message || JSON.stringify(err)));
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="relative min-h-screen flex justify-center items-center p-6 overflow-hidden">
      {/* 🔥 Animated gradient background */}
      <div className="absolute inset-0 bg-gradient-to-r from-red-500 via-yellow-400 to-white animate-gradient bg-[length:400%_400%]" />

      {/* Form Card */}
      <motion.div
        initial={{ opacity: 0, y: 40, scale: 0.95 }}
        animate={{ opacity: 1, y: 0, scale: 1 }}
        transition={{ duration: 0.6 }}
        className="relative bg-white/90 backdrop-blur-xl border border-red-200 shadow-2xl rounded-2xl p-8 w-full max-w-lg"
      >
        <h1 className="text-3xl font-extrabold text-center bg-clip-text text-transparent bg-gradient-to-r from-red-600 to-yellow-600 mb-6">
          Admin — Add Package
        </h1>

        <form onSubmit={handleAdd} className="space-y-5">
          <input
            type="text"
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            placeholder="Package Title"
            required
            className="w-full border border-gray-300 rounded-lg p-3 focus:ring-2 focus:ring-red-400 focus:outline-none"
          />

          <textarea
            value={desc}
            onChange={(e) => setDesc(e.target.value)}
            placeholder="Description"
            rows={3}
            className="w-full border border-gray-300 rounded-lg p-3 focus:ring-2 focus:ring-yellow-400 focus:outline-none"
          />

          <input
            type="number"
            value={price}
            onChange={(e) => setPrice(e.target.value)}
            placeholder="Price"
            required
            className="w-full border border-gray-300 rounded-lg p-3 focus:ring-2 focus:ring-red-400 focus:outline-none"
          />

          <select
            value={category}
            onChange={(e) => setCategory(e.target.value)}
            className="w-full border border-gray-300 rounded-lg p-3 focus:ring-2 focus:ring-yellow-400 focus:outline-none"
          >
            <option value="Stall">Stall</option>
            <option value="Decoration">Decoration</option>
            <option value="DJ">DJ</option>
            <option value="Venues">Venues</option>
          </select>

          <input
            type="file"
            accept="image/*"
            onChange={(e) => setFile(e.target.files[0])}
            className="w-full border border-gray-300 rounded-lg p-3 cursor-pointer bg-white hover:bg-gray-50 transition"
          />

          <motion.button
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.97 }}
            type="submit"
            disabled={loading}
            className={`w-full py-3 rounded-lg text-white font-semibold transition ${
              loading
                ? "bg-gray-400 cursor-not-allowed"
                : "bg-gradient-to-r from-red-600 to-yellow-500 hover:opacity-90"
            }`}
          >
            {loading ? "Adding..." : "Add Package"}
          </motion.button>
        </form>
      </motion.div>

      {/* 🔄 Gradient Animation Keyframes */}
      <style>{`
        @keyframes gradient {
          0% { background-position: 0% 50%; }
          50% { background-position: 100% 50%; }
          100% { background-position: 0% 50%; }
        }
        .animate-gradient {
          animation: gradient 8s ease infinite;
        }
      `}</style>
    </div>
  );
}
