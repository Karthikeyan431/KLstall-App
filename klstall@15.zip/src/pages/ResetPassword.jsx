// src/ResetPassword.jsx
import { useState } from "react";
import { supabase } from "../lib/supabase";
import { Link } from "react-router-dom";

export default function ResetPassword() {
  const [email, setEmail] = useState("");
  const [message, setMessage] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  const handleReset = async (e) => {
    e.preventDefault();
    setMessage("");
    setError("");
    setLoading(true);

    if (!email) {
      setError("Please enter your email.");
      setLoading(false);
      return;
    }

    const { error } = await supabase.auth.resetPasswordForEmail(email, {
      redirectTo: `${window.location.origin}/update-password`,
    });

    if (error) setError(error.message);
    else setMessage("If the email exists, you will receive a reset link shortly.");

    setLoading(false);
  };

  return (
    <div className="fixed inset-0 flex items-center justify-center min-h-screen bg-gradient-to-br from-red-700 via-yellow-500 to-white text-white animate-gradient">
      <div className="max-w-md w-full bg-white/10 backdrop-blur-md p-8 rounded-2xl shadow-2xl border border-white/20">
        <h2 className="text-2xl font-bold text-white mb-3 text-center drop-shadow-lg">
          Reset Your Password
        </h2>
        <p className="text-sm text-yellow-200 text-center mb-6">
          We’ll send a reset link to your email address.
        </p>

        <form onSubmit={handleReset} className="space-y-4">
          <input
            type="email"
            placeholder="Enter your email"
            className="w-full p-3 rounded-lg border border-yellow-300 bg-white/90 text-red-700 placeholder-red-400 focus:ring-2 focus:ring-yellow-400 outline-none transition"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            required
          />

          {error && <div className="text-sm text-red-600 font-semibold">{error}</div>}
          {message && <div className="text-sm text-green-600 font-semibold">{message}</div>}

          <button
            type="submit"
            disabled={loading}
            className="w-full py-3 rounded-lg font-semibold bg-gradient-to-r from-red-600 to-yellow-400 text-white shadow-lg hover:scale-105 transition-transform"
          >
            {loading ? "Sending..." : "Send Reset Link"}
          </button>
        </form>

        <div className="mt-4 text-sm text-center">
          <Link
            to="/login"
            className="text-yellow-200 hover:underline hover:text-white transition"
          >
            ⬅ Back to Login
          </Link>
        </div>
      </div>
    </div>
  );
}
