// src/Dashboard.jsx
import { useEffect, useState } from 'react'
import { supabase } from '../lib/supabase'
import { useNavigate } from 'react-router-dom'
import { motion } from 'framer-motion'

export default function Dashboard() {
  const [user, setUser] = useState(null)
  const navigate = useNavigate()

  useEffect(() => {
    const getUser = async () => {
      const { data } = await supabase.auth.getUser()
      setUser(data?.user ?? null)
    }
    getUser()
    const { subscription } = supabase.auth.onAuthStateChange((_event, session) => {
      setUser(session?.user ?? null)
    })
    return () => subscription?.unsubscribe()
  }, [])

  const handleSignOut = async () => {
    await supabase.auth.signOut()
    navigate('/login')
  }

  return (
    <div className="fixed inset-0 min-h-screen bg-gradient-to-br from-red-700 via-yellow-400 to-white overflow-hidden p-8 flex justify-center items-start">
      
      {/* Animated Blobs */}
      <motion.div
        animate={{ scale: [1, 1.2, 1] }}
        transition={{ repeat: Infinity, duration: 6 }}
        className="absolute w-[30rem] h-[30rem] bg-yellow-300 rounded-full mix-blend-multiply filter blur-3xl opacity-40 top-10 left-0"
      />
      <motion.div
        animate={{ scale: [1.1, 0.9, 1.1] }}
        transition={{ repeat: Infinity, duration: 8 }}
        className="absolute w-[28rem] h-[28rem] bg-red-500 rounded-full mix-blend-multiply filter blur-3xl opacity-40 bottom-10 right-0"
      />

      {/* Floating Sparkles */}
      {Array.from({ length: 15 }).map((_, i) => (
        <motion.div
          key={i}
          className="absolute w-1 h-1 bg-white rounded-full shadow-md"
          initial={{ x: Math.random() * window.innerWidth, y: Math.random() * window.innerHeight }}
          animate={{ y: [null, -20], opacity: [1, 0] }}
          transition={{ duration: Math.random() * 5 + 4, repeat: Infinity, delay: Math.random() * 5 }}
        />
      ))}

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.8 }}
        className="relative z-10 w-full max-w-3xl bg-white/20 backdrop-blur-xl border border-white/30 rounded-2xl shadow-2xl p-6"
      >
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold text-red-900">Dashboard</h1>
            <p className="text-yellow-900/80 mt-1">Welcome to KL STALL</p>
          </div>
          <motion.button
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            onClick={handleSignOut}
            className="px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700 transition"
          >
            Sign out
          </motion.button>
        </div>

        <div className="mt-8">
          <h2 className="text-xl font-semibold text-red-800 mb-4">Account Details</h2>
          <div className="space-y-2 text-red-900">
            <div><strong>Email:</strong> {user?.email ?? '—'}</div>
            <div><strong>User ID:</strong> {user?.id ?? '—'}</div>
          </div>
        </div>

        <div className="mt-8 grid grid-cols-1 sm:grid-cols-2 gap-4">
          <motion.div
            whileHover={{ scale: 1.05 }}
            className="p-4 bg-yellow-200/30 rounded-xl shadow-lg"
          >
            <h3 className="text-red-900 font-semibold mb-2">Manage Packages</h3>
            <p className="text-red-800 text-sm">Add, edit, or remove event packages easily.</p>
            <button
              onClick={() => navigate('/admin')}
              className="mt-2 px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700 transition"
            >
              Go
            </button>
          </motion.div>

          <motion.div
            whileHover={{ scale: 1.05 }}
            className="p-4 bg-yellow-200/30 rounded-xl shadow-lg"
          >
            <h3 className="text-red-900 font-semibold mb-2">View Orders</h3>
            <p className="text-red-800 text-sm">Check customer orders and their details.</p>
            <button
              onClick={() => navigate('/orders')}
              className="mt-2 px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700 transition"
            >
              Go
            </button>
          </motion.div>
        </div>
      </motion.div>
    </div>
  )
}
