import React from "react";
import { useCart } from "../contexts/CartContext";
import { useNavigate } from "react-router-dom";

export default function Cart() {
  const { cart, removeFromCart, updateQuantity, clearCart } = useCart();
  const navigate = useNavigate();

  const totalPrice = cart.reduce(
    (sum, item) => sum + item.price * (item.quantity || 1),
    0
  );

  // ✅ Place Order Function
  const handlePlaceOrder = () => {
    if (cart.length === 0) {
      alert("Your cart is empty!");
      return;
    }

    const newOrder = {
      id: Date.now(),
      date: new Date().toLocaleString(),
      items: cart,
      totalPrice,
    };

    // Save order in localStorage
    const existingOrders = JSON.parse(localStorage.getItem("orders")) || [];
    existingOrders.push(newOrder);
    localStorage.setItem("orders", JSON.stringify(existingOrders));

    // Clear cart after ordering
    clearCart();

    // Redirect to orders page
    navigate("/orders");
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-red-500 via-yellow-400 to-white p-6">
      <h1 className="text-3xl font-bold text-white mb-6 text-center">
        🛍️ Your Cart
      </h1>

      {cart.length === 0 ? (
        <p className="text-center text-gray-800 text-lg">
          Your cart is empty.
        </p>
      ) : (
        <div className="max-w-4xl mx-auto bg-white rounded-2xl shadow-xl p-6">
          {cart.map((item) => (
            <div
              key={item.id}
              className="flex justify-between items-center border-b py-4"
            >
              <div>
                <h2 className="text-xl font-semibold text-red-600">
                  {item.title}
                </h2>
                <p className="text-gray-600">₹ {item.price}</p>
              </div>

              <div className="flex items-center gap-3">
                <button
                  onClick={() =>
                    updateQuantity(item.id, (item.quantity || 1) - 1)
                  }
                  className="px-3 py-1 bg-yellow-500 text-white rounded-lg hover:bg-yellow-600"
                >
                  −
                </button>
                <span className="font-semibold text-lg">
                  {item.quantity || 1}
                </span>
                <button
                  onClick={() =>
                    updateQuantity(item.id, (item.quantity || 1) + 1)
                  }
                  className="px-3 py-1 bg-yellow-500 text-white rounded-lg hover:bg-yellow-600"
                >
                  +
                </button>
                <button
                  onClick={() => removeFromCart(item.id)}
                  className="ml-4 bg-red-500 text-white px-3 py-1 rounded-lg hover:bg-red-600"
                >
                  Remove
                </button>
              </div>
            </div>
          ))}

          <div className="text-right mt-6">
            <h3 className="text-xl font-bold text-gray-800">
              Total: ₹ {totalPrice}
            </h3>
            <button
              onClick={handlePlaceOrder}
              className="mt-4 px-6 py-3 bg-red-600 text-white rounded-xl hover:bg-yellow-500 transition-all"
            >
              🧾 Order Now
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
