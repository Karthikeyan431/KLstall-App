// src/pages/Orders.jsx
import React, { useEffect, useRef, useState } from "react";
import { jsPDF } from "jspdf";
import html2canvas from "html2canvas";

/*
  How it works:
  - A hidden DOM invoice is rendered into invoiceRef.
  - html2canvas captures that DOM (so fonts, rupee symbol, emojis & logo appear correctly).
  - The resulting image is scaled to fit onto one A4 PDF page and saved.
*/

const LOGO_URL = " https://i.ibb.co/FkYCyrW1/IMG-20250917-214439-removebg-preview.png "; // replace if you want another hosted image

export default function Orders() {
  const [orders, setOrders] = useState([]);
  const [expandedOrder, setExpandedOrder] = useState(null);
  const invoiceRef = useRef(null);        // hidden invoice DOM
  const [currentOrderForPdf, setCurrentOrderForPdf] = useState(null);
  const [isGenerating, setIsGenerating] = useState(false);

  useEffect(() => {
    const savedOrders = JSON.parse(localStorage.getItem("orders")) || [];
    setOrders(savedOrders);
  }, []);

  const toggleExpand = (orderId) => {
    setExpandedOrder(expandedOrder === orderId ? null : orderId);
  };

  // Robust date formatter -> Asia/Kolkata, fallback if invalid date
  const formatDateTime = (raw) => {
    try {
      const d = new Date(raw);
      if (Number.isNaN(d.getTime())) return String(raw);
      return new Intl.DateTimeFormat("en-IN", {
        dateStyle: "medium",
        timeStyle: "short",
        timeZone: "Asia/Kolkata",
      }).format(d);
    } catch {
      return String(raw);
    }
  };

  // Prepare DOM invoice and capture to PDF using html2canvas
  const handleDownloadInvoice = async (order) => {
    if (!order) return;
    setCurrentOrderForPdf(order);
    setIsGenerating(true);

    // Wait a tick so the hidden DOM invoice updates (invoiceRef will render currentOrderForPdf)
    await new Promise((r) => setTimeout(r, 100));

    try {
      const invoiceEl = invoiceRef.current;
      if (!invoiceEl) throw new Error("Invoice element not ready");

      // html2canvas options: useCORS true so remote images (logo) with CORS allowed can be captured.
      const canvas = await html2canvas(invoiceEl, {
        scale: 2,            // increase resolution for crisp PDF
        useCORS: true,
        allowTaint: false,
        backgroundColor: null,
        logging: false,
      });

      const imgData = canvas.toDataURL("image/png");

      const pdf = new jsPDF({
        orientation: "p",
        unit: "mm",
        format: "a4",
      });

      const pageWidth = pdf.internal.pageSize.getWidth();
      const pageHeight = pdf.internal.pageSize.getHeight();

      // Calculate image display size to fit inside page with small margins
      const margin = 10;
      const usableW = pageWidth - margin * 2;
      const usableH = pageHeight - margin * 2;

      // image dims in px
      const imgW = canvas.width;
      const imgH = canvas.height;

      // convert px -> mm (approx) using 96 DPI: mm = px * 25.4 / 96
      const pxToMm = (px) => (px * 25.4) / 96;
      const imgWmm = pxToMm(imgW);
      const imgHmm = pxToMm(imgH);

      const scale = Math.min(usableW / imgWmm, usableH / imgHmm, 1);

      const drawW = imgWmm * scale;
      const drawH = imgHmm * scale;
      const x = (pageWidth - drawW) / 2;
      const y = (pageHeight - drawH) / 2;

      pdf.addImage(imgData, "PNG", x, y, drawW, drawH);
      pdf.save(`KLSTALL_Invoice_${order.id}.pdf`);
    } catch (err) {
      console.error("Failed to generate PDF (html2canvas/jsPDF):", err);
      alert(
        "Failed to generate invoice PDF. Check browser console for details. Common causes: logo host blocks CORS."
      );
    } finally {
      setIsGenerating(false);
      // clear selection
      setCurrentOrderForPdf(null);
    }
  };

  return (
    <>
      {/* Visible Orders UI */}
      <div className="min-h-screen bg-gradient-to-br from-yellow-400 via-red-400 to-white p-6">
        <h1 className="text-3xl font-extrabold text-white mb-8 text-center drop-shadow-lg">
          📦 Your Orders
        </h1>

        {orders.length === 0 ? (
          <p className="text-center text-gray-800 text-lg">
            No orders yet. Go add some packages!
          </p>
        ) : (
          <div className="max-w-4xl mx-auto bg-white/95 rounded-2xl shadow-xl p-6 space-y-4">
            {orders.map((order) => (
              <div
                key={order.id}
                onClick={() => toggleExpand(order.id)}
                className="bg-white border border-gray-200 rounded-xl p-5 cursor-pointer hover:shadow-lg transition"
              >
                <div className="flex justify-between items-center">
                  <div>
                    <h2 className="text-lg font-semibold text-red-600">
                      Order #{order.id}
                    </h2>
                    <p className="text-gray-600 text-sm">
                      {formatDateTime(order.date)}
                    </p>
                  </div>
                  <div className="flex gap-2 items-center">
                    <p className="text-gray-700 font-bold">
                      {/* use INR label plus symbol — browser renders ₹ correctly */}
                      ₹{(order.totalPrice || 0).toFixed(2)}
                    </p>
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        handleDownloadInvoice(order);
                      }}
                      className="px-3 py-2 bg-red-600 text-white rounded-lg hover:bg-yellow-500 transition text-sm"
                      disabled={isGenerating}
                    >
                      {isGenerating ? "Generating..." : "⬇️ PDF"}
                    </button>
                  </div>
                </div>

                {expandedOrder === order.id && (
                  <div className="mt-4 border-t border-gray-300 pt-3 animate-fadeIn">
                    {Array.isArray(order.items) && order.items.length > 0 ? (
                      order.items.map((item, index) => (
                        <div
                          key={index}
                          className="flex justify-between items-center py-2 border-b border-gray-100"
                        >
                          <p className="text-gray-700">
                            {item.title} (x{item.quantity || 1})
                          </p>
                          <p className="font-medium text-gray-800">
                            ₹{((item.price || 0) * (item.quantity || 1)).toFixed(2)}
                          </p>
                        </div>
                      ))
                    ) : (
                      <p className="text-gray-500">No items recorded for this order.</p>
                    )}

                    <p className="text-right mt-3 font-bold text-red-600">
                      Total: ₹{(order.totalPrice || 0).toFixed(2)}
                    </p>
                  </div>
                )}
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Hidden invoice DOM used for html2canvas snapshot.
          Note: style here controls how the final PDF will look.
          Keep this DOM hidden from users (off-screen) but rendered.
      */}
      <div
        style={{
          position: "fixed",
          left: -9999,
          top: -9999,
          width: "794px", // A4 @ 96dpi ≈ 794px wide (210mm)
          padding: 20,
          background: "#fff",
        }}
        aria-hidden
      >
        <div ref={invoiceRef} id="invoice-capture" style={{ width: "754px", boxSizing: "border-box", padding: 16 }}>
          {/* dynamic content: if currentOrderForPdf is null use a placeholder */}
          {currentOrderForPdf ? (
            <div style={{ fontFamily: "Poppins, Inter, Arial, sans-serif", color: "#222" }}>
              {/* Header */}
              <div style={{ display: "flex", gap: 12, alignItems: "center", marginBottom: 8 }}>
                <img
                  src={LOGO_URL}
                  alt="logo"
                  style={{ width: 80, height: 80, objectFit: "contain" }}
                  crossOrigin="anonymous"
                />
                <div>
                  <div style={{ fontSize: 22, fontWeight: 700, color: "#DC3545" }}>KL STALL & DECORS</div>
                  <div style={{ fontSize: 12, color: "#333" }}>Event Management | Stall | Decoration | DJ | Venue </div>
                  <div style={{ fontSize: 12, color: "#333", marginTop: 4 }}>
                    Location: Thirukkazhukundram &nbsp;|&nbsp; Phone: +91 9566061075
                  </div>
                </div>
              </div>

              <hr style={{ border: "none", borderTop: "2px solid #eee", margin: "8px 0 12px" }} />

              {/* Invoice meta */}
              <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 12 }}>
                <div>
                  <div style={{ fontSize: 12, color: "#666" }}>Invoice ID</div>
                  <div style={{ fontSize: 14, fontWeight: 700 }}>#{currentOrderForPdf.id}</div>
                </div>
                <div>
                  <div style={{ fontSize: 12, color: "#666" }}>Date / Time (IST)</div>
                  <div style={{ fontSize: 14, fontWeight: 700 }}>{formatDateTime(currentOrderForPdf.date)}</div>
                </div>
              </div>

              {/* Items table */}
              <table style={{ width: "100%", borderCollapse: "collapse", marginTop: 6 }}>
                <thead>
                  <tr>
                    <th style={{ borderBottom: "2px solid #f3f3f3", textAlign: "left", padding: 8 }}>#</th>
                    <th style={{ borderBottom: "2px solid #f3f3f3", textAlign: "left", padding: 8 }}>Item</th>
                    <th style={{ borderBottom: "2px solid #f3f3f3", textAlign: "right", padding: 8 }}>Price</th>
                    <th style={{ borderBottom: "2px solid #f3f3f3", textAlign: "center", padding: 8 }}>Qty</th>
                    <th style={{ borderBottom: "2px solid #f3f3f3", textAlign: "right", padding: 8 }}>Total</th>
                  </tr>
                </thead>
                <tbody>
                  {Array.isArray(currentOrderForPdf.items) && currentOrderForPdf.items.length > 0 ? (
                    currentOrderForPdf.items.map((it, i) => (
                      <tr key={i}>
                        <td style={{ padding: 8 }}>{i + 1}</td>
                        <td style={{ padding: 8 }}>{it.title}</td>
                        <td style={{ padding: 8, textAlign: "right" }}>₹ {(it.price || 0).toFixed(2)}</td>
                        <td style={{ padding: 8, textAlign: "center" }}>{it.quantity || 1}</td>
                        <td style={{ padding: 8, textAlign: "right" }}>₹ {((it.price || 0) * (it.quantity || 1)).toFixed(2)}</td>
                      </tr>
                    ))
                  ) : (
                    <tr>
                      <td colSpan={5} style={{ padding: 12, color: "#666" }}>
                        No items recorded
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>

              {/* Summary */}
              <div style={{ display: "flex", justifyContent: "flex-end", marginTop: 12 }}>
                <div style={{ background: "#fff3f0", padding: 10, borderRadius: 6, textAlign: "right" }}>
                  <div style={{ fontSize: 12, color: "#666" }}>Grand Total</div>
                  <div style={{ fontSize: 18, fontWeight: 700, color: "#C82333" }}>
                    ₹ {(currentOrderForPdf.totalPrice || 0).toFixed(2)}
                  </div>
                </div>
              </div>

              <div style={{ marginTop: 18, fontSize: 12, color: "#666" }}>
                <div>Thank you for choosing KL Stall & Decors — we make your events memorable.</div>
              </div>
            </div>
          ) : (
            <div style={{ padding: 16, color: "#666" }}>Preparing invoice preview…</div>
          )}
        </div>
      </div>
    </>
  );
}
