// src/pages/AdminPackages.jsx
import React, { useState } from "react";
import { supabase } from "../lib/supabase";

export default function AdminPackages() {
  const [title, setTitle] = useState("");
  const [price, setPrice] = useState("");
  const [desc, setDesc] = useState("");
  const [file, setFile] = useState(null);
  const [loading, setLoading] = useState(false);

  async function handleAdd(e) {
    e.preventDefault();
    setLoading(true);
    try {
      let imageUrl = null;

      if (file) {
        const fileName = `${Date.now()}_${file.name}`;
        const { error: uploadError } = await supabase.storage
          .from("package-images")
          .upload(fileName, file);

        if (uploadError) throw uploadError;

        const { data: publicData } = supabase.storage
          .from("package-images")
          .getPublicUrl(fileName);

        imageUrl = publicData.publicUrl;
      }

      const { error: insertError } = await supabase
        .from("packages")
        .insert([{ title, description: desc, price, image_url: imageUrl }]);

      if (insertError) throw insertError;

      alert("✅ Package added successfully!");
      setTitle("");
      setDesc("");
      setPrice("");
      setFile(null);
    } catch (err) {
      console.error("Error adding package:", err);
      alert("Error: " + (err.message || JSON.stringify(err)));
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="min-h-screen flex flex-col items-center justify-center bg-gradient-to-br from-red-600 via-yellow-400 to-white bg-[length:400%_400%] animate-[gradientShift_12s_ease_infinite] p-6">
      <div className="bg-white/90 backdrop-blur-md rounded-2xl shadow-2xl p-8 w-full max-w-lg border border-yellow-300 animate-fadeIn">
        <h2 className="text-3xl font-extrabold text-center mb-6 text-red-700 drop-shadow-[0_0_10px_rgba(255,0,0,0.3)]">
          Admin — Add Package
        </h2>

        <form onSubmit={handleAdd} className="space-y-5">
          <div>
            <label className="block text-sm font-semibold text-gray-700 mb-1">
              Title
            </label>
            <input
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="Package Title"
              required
              className="w-full px-4 py-2 border-2 border-yellow-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-red-500 focus:border-transparent shadow-sm"
            />
          </div>

          <div>
            <label className="block text-sm font-semibold text-gray-700 mb-1">
              Description
            </label>
            <textarea
              value={desc}
              onChange={(e) => setDesc(e.target.value)}
              placeholder="Description"
              rows={3}
              className="w-full px-4 py-2 border-2 border-yellow-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-red-500 focus:border-transparent shadow-sm"
            />
          </div>

          <div>
            <label className="block text-sm font-semibold text-gray-700 mb-1">
              Price (₹)
            </label>
            <input
              value={price}
              onChange={(e) => setPrice(e.target.value)}
              placeholder="Enter price"
              type="number"
              step="0.01"
              required
              className="w-full px-4 py-2 border-2 border-yellow-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-red-500 focus:border-transparent shadow-sm"
            />
          </div>

          <div>
            <label className="block text-sm font-semibold text-gray-700 mb-1">
              Upload Image
            </label>
            <input
              type="file"
              accept="image/*"
              onChange={(e) => setFile(e.target.files[0])}
              className="w-full file:mr-4 file:py-2 file:px-4 file:rounded-lg file:border-0 file:bg-gradient-to-r file:from-red-500 file:to-yellow-400 file:text-white file:font-semibold hover:file:opacity-90"
            />
          </div>

          <button
            type="submit"
            disabled={loading}
            className={`w-full py-3 rounded-lg font-bold text-lg text-white transition-all duration-300 shadow-lg ${
              loading
                ? "bg-gray-400 cursor-not-allowed"
                : "bg-gradient-to-r from-red-600 via-yellow-500 to-yellow-400 hover:scale-105 hover:shadow-[0_0_20px_rgba(255,215,0,0.7)]"
            }`}
          >
            {loading ? "Adding..." : "Add Package"}
          </button>
        </form>
      </div>
    </div>
  );
}
