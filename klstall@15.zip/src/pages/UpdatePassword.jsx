// src/UpdatePassword.jsx
import { useState, useEffect } from 'react'
import { supabase } from '../lib/supabase'
import { useNavigate, Link } from 'react-router-dom'
import { motion } from 'framer-motion'

export default function UpdatePassword() {
  const [password, setPassword] = useState('')
  const [message, setMessage] = useState('')
  const [error, setError] = useState('')
  const [loading, setLoading] = useState(false)
  const [sessionReady, setSessionReady] = useState(false)
  const navigate = useNavigate()

  useEffect(() => {
    const check = async () => {
      const { data } = await supabase.auth.getSession()
      setSessionReady(!!data?.session)
    }
    check()

    const { subscription } = supabase.auth.onAuthStateChange((_event, session) => {
      if (session) setSessionReady(true)
    })
    return () => subscription?.unsubscribe()
  }, [])

  const handleUpdate = async (e) => {
    e.preventDefault()
    setError('')
    setMessage('')
    setLoading(true)

    if (!password || password.length < 6) {
      setError('Please enter a password with at least 6 characters.')
      setLoading(false)
      return
    }

    const { error } = await supabase.auth.updateUser({ password })
    if (error) setError(error.message)
    else {
      setMessage('Password updated! Redirecting to login...')
      setTimeout(() => navigate('/login'), 2000)
    }
    setLoading(false)
  }

  return (
    <div className="fixed inset-0 min-h-screen bg-gradient-to-br from-red-700 via-yellow-400 to-white flex items-center justify-center p-6 relative">
      {/* Subtle animated glow */}
      <motion.div
        animate={{ scale: [1, 1.1, 1] }}
        transition={{ repeat: Infinity, duration: 6 }}
        className="absolute w-[25rem] h-[25rem] bg-yellow-300 rounded-full mix-blend-multiply filter blur-3xl opacity-40 top-10 left-0"
      />
      <motion.div
        animate={{ scale: [1.1, 0.9, 1.1] }}
        transition={{ repeat: Infinity, duration: 8 }}
        className="absolute w-[28rem] h-[28rem] bg-red-400 rounded-full mix-blend-multiply filter blur-3xl opacity-40 bottom-10 right-0"
      />

      <motion.div
        initial={{ opacity: 0, y: 40 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.8 }}
        className="relative z-10 max-w-md w-full bg-white/95 p-8 rounded-2xl shadow-xl"
      >
        <h2 className="text-2xl font-semibold text-red-900 mb-2">Set a new password</h2>
        <p className="text-sm text-red-800 mb-6">
          Create a new password for your account.
        </p>

        {!sessionReady && (
          <div className="mb-4 text-sm text-red-700">
            Waiting for session from Supabase (open the link from your email).
          </div>
        )}

        <form onSubmit={handleUpdate} className="space-y-4">
          <motion.input
            whileFocus={{ scale: 1.02 }}
            type="password"
            placeholder="New password"
            className="w-full p-3 rounded-lg border border-red-400 focus:ring-2 focus:ring-red-500"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            required
            minLength={6}
          />

          {error && <div className="text-sm text-red-600">{error}</div>}
          {message && <div className="text-sm text-green-600">{message}</div>}

          <motion.button
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            type="submit"
            disabled={loading || !sessionReady}
            className="w-full bg-red-600 text-white py-3 rounded-lg hover:bg-red-700 transition"
          >
            {loading ? 'Updating...' : 'Update password'}
          </motion.button>
        </form>

        <div className="mt-4 text-sm text-red-800">
          <Link to="/login" className="hover:underline text-yellow-600">
            Back to login
          </Link>
        </div>
      </motion.div>
    </div>
  )
}
