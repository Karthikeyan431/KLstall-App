// src/pages/Profile.jsx
import React, { useEffect, useState, useRef } from "react";
import { motion } from "framer-motion";
import { supabase } from "../lib/supabase";
import { useNavigate } from "react-router-dom";

export default function Profile() {
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [profile, setProfile] = useState({});
  const [name, setName] = useState("");
  const [phone, setPhone] = useState("");
  const [about, setAbout] = useState("");
  const [avatarPreview, setAvatarPreview] = useState(null);
  const [oldFilePath, setOldFilePath] = useState(null);
  const fileRef = useRef(null);
  const navigate = useNavigate();

  useEffect(() => {
    let mounted = true;

    async function load() {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) {
        navigate("/login");
        return;
      }

      const { data, error } = await supabase
        .from("profiles")
        .select("*")
        .eq("id", user.id)
        .single();

      if (error && error.code !== "PGRST116") console.error(error);

      if (mounted) {
        setProfile(data ?? {});
        setName(data?.full_name ?? "");
        setPhone(data?.phone ?? "");
        setAbout(data?.about ?? "");
        setAvatarPreview(data?.avatar_url ?? null);
        setLoading(false);
      }
    }

    load();
    return () => { mounted = false; };
  }, [navigate]);

  async function uploadAvatar(file, userId) {
    if (!file) return null;
    const filePath = `${userId}/${Date.now()}-${file.name}`;
    const { error: uploadError } = await supabase
      .storage
      .from("Uploads")
      .upload(filePath, file, { upsert: true });

    if (uploadError) throw uploadError;

    if (oldFilePath) {
      try {
        await supabase.storage.from("Uploads").remove([oldFilePath]);
      } catch (e) {
        console.warn("Old file remove failed", e);
      }
    }
    setOldFilePath(filePath);
    const { data } = supabase.storage.from("Uploads").getPublicUrl(filePath);
    return data.publicUrl;
  }

  const handleFileChange = async (file) => {
    if (!file) return;
    setAvatarPreview(URL.createObjectURL(file));

    try {
      const { data: { user } } = await supabase.auth.getUser();
      const publicUrl = await uploadAvatar(file, user.id);
      setProfile((p) => ({ ...p, avatar_url: publicUrl }));

      await supabase
        .from("profiles")
        .upsert({ id: user.id, avatar_url: publicUrl });
    } catch (err) {
      alert("Upload failed: " + (err.message || err));
    }
  };

  async function save(e) {
    e.preventDefault();
    setSaving(true);
    const { data: { user } } = await supabase.auth.getUser();

    const { error } = await supabase.from("profiles").upsert({
      id: user.id,
      full_name: name,
      phone,
      about,
      avatar_url: profile?.avatar_url ?? null,
    });

    if (error) alert(error.message);
    else alert("Profile Saved ✅");
    setSaving(false);
  }

  if (loading)
    return (
      <div className="min-h-screen flex items-center justify-center text-gray-600 text-lg">
        Loading your profile...
      </div>
    );

  const completion = Math.round(
    (["name", "phone", "avatar_url", "about"].filter(
      (f) => f && (profile[f] || (f === "name" && name) || (f === "phone" && phone) || (f === "about" && about))
    ).length /
      4) *
      100
  );

  return (
    <div className="relative min-h-screen flex items-center justify-center p-6 overflow-hidden">
      {/* 🔥 Animated background gradient */}
      <div className="absolute inset-0 bg-gradient-to-r from-red-500 via-yellow-400 to-white animate-gradient bg-[length:400%_400%]"></div>

      <motion.div
        initial={{ opacity: 0, scale: 0.96 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ duration: 0.5 }}
        className="relative w-full max-w-2xl bg-white/90 backdrop-blur-xl border border-red-200 rounded-2xl shadow-2xl p-6"
      >
        <h2 className="text-3xl font-extrabold text-center bg-clip-text text-transparent bg-gradient-to-r from-red-600 to-yellow-600 mb-6">
          Your Profile
        </h2>

        {/* Avatar */}
        <div className="flex flex-col sm:flex-row items-center gap-6 mb-6">
          <div className="relative group">
            <div className="w-28 h-28 rounded-full overflow-hidden border-4 border-yellow-400 shadow-lg">
              {avatarPreview ? (
                <img
                  src={avatarPreview}
                  alt="avatar"
                  className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300"
                />
              ) : (
                <div className="w-full h-full flex items-center justify-center text-gray-400 text-sm">
                  No Avatar
                </div>
              )}
            </div>
            <div
              onClick={() => fileRef.current?.click()}
              className="absolute inset-0 bg-black/50 text-white opacity-0 group-hover:opacity-100 flex items-center justify-center text-sm cursor-pointer rounded-full transition"
            >
              Change Photo
            </div>
            <input
              type="file"
              ref={fileRef}
              accept="image/*"
              className="hidden"
              onChange={(e) => handleFileChange(e.target.files[0])}
            />
          </div>

          <div className="flex-1">
            <p className="text-gray-600 mb-2">
              Upload or change your profile picture.
            </p>
            <motion.div
              className="w-full bg-gray-200 h-2 rounded-full overflow-hidden"
              initial={{ width: 0 }}
              animate={{ width: "100%" }}
            >
              <motion.div
                className="bg-gradient-to-r from-red-500 to-yellow-400 h-full"
                style={{ width: `${completion}%` }}
                transition={{ duration: 0.5 }}
              />
            </motion.div>
            <p className="text-xs text-gray-600 mt-1">
              Profile {completion}% complete
            </p>
          </div>
        </div>

        {/* Profile Form */}
        <form onSubmit={save} className="grid gap-4">
          <input
            className="p-3 rounded-lg border border-gray-200 focus:ring-2 focus:ring-red-400 focus:outline-none"
            value={name}
            onChange={(e) => setName(e.target.value)}
            placeholder="Full name"
          />
          <input
            className="p-3 rounded-lg border border-gray-200 focus:ring-2 focus:ring-yellow-400 focus:outline-none"
            value={phone}
            onChange={(e) => setPhone(e.target.value)}
            placeholder="Phone"
          />
          <textarea
            className="p-3 rounded-lg border border-gray-200 focus:ring-2 focus:ring-yellow-400 focus:outline-none"
            value={about}
            onChange={(e) => setAbout(e.target.value)}
            placeholder="About you (optional)"
            rows={3}
          />

          <div className="flex justify-between items-center mt-4">
            <button
              type="button"
              onClick={() => navigate("/")}
              className="px-4 py-2 rounded-lg border border-gray-300 text-gray-700 hover:bg-gray-100 transition"
            >
              ← Back
            </button>
            <button
              type="submit"
              disabled={saving}
              className="px-6 py-2 rounded-lg bg-gradient-to-r from-red-600 to-yellow-500 text-white font-semibold hover:opacity-90 transition"
            >
              {saving ? "Saving..." : "Save Profile"}
            </button>
          </div>
        </form>
      </motion.div>

      {/* 🔄 Animation keyframes */}
      <style>{`
        @keyframes gradient {
          0% { background-position: 0% 50%; }
          50% { background-position: 100% 50%; }
          100% { background-position: 0% 50%; }
        }
        .animate-gradient {
          animation: gradient 8s ease infinite;
        }
      `}</style>
    </div>
  );
}
