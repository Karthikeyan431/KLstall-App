// src/components/Navbar.jsx
import React, { useState } from "react";
import { Link, useLocation, useNavigate } from "react-router-dom";
import { useAuth } from "../contexts/AuthContext";
import { useCart } from "../contexts/CartContext";

export default function Navbar() {
  const { user, isAdmin, logout } = useAuth();
  const { cart } = useCart();
  const location = useLocation();
  const navigate = useNavigate();
  const [isOpen, setIsOpen] = useState(false);

  const links = [
    { name: "Home", path: "/" },
    { name: "Packages", path: "/packages" },
    { name: "Profile", path: "/profile" },
  ];

  const handleLogout = async () => {
    try {
      await logout();
      setIsOpen(false);
      navigate("/login");
    } catch (err) {
      console.error("Logout error:", err);
    }
  };

  return (
    <nav className="fixed top-0 left-0 w-full z-50 backdrop-blur-xl shadow-lg animate-fadeIn bg-gradient-to-r from-red-600 via-yellow-400 to-white bg-[length:400%_400%] animate-[gradientShift_10s_ease_infinite]">
      <div className="w-full px-5 sm:px-8 flex items-center justify-between h-16">
        {/* Logo + Brand */}
        <Link
          to="/"
          className="flex items-center space-x-2 hover:scale-105 transition-transform duration-300"
        >
          <img
            src="https://i.ibb.co/FkYCyrW1/IMG-20250917-214439-removebg-preview.png"
            alt="Logo"
            className="h-10 w-auto drop-shadow-[0_0_10px_rgba(255,255,255,0.9)]"
          />
          <span className="font-extrabold text-xl text-white tracking-wider drop-shadow-[0_0_8px_rgba(255,215,0,0.8)]">
            KL STALL
          </span>
        </Link>

        {/* Desktop Menu */}
        <div className="hidden md:flex items-center space-x-6">
          {links.map((l) => (
            <Link
              key={l.path}
              to={l.path}
              className={`transition duration-300 font-medium ${
                location.pathname === l.path
                  ? "text-yellow-300 font-semibold drop-shadow-[0_0_6px_rgba(255,255,255,0.8)]"
                  : "text-white hover:text-yellow-400"
              }`}
            >
              {l.name}
            </Link>
          ))}

          {isAdmin && (
            <Link
              to="/admin"
              className={`transition duration-300 ${
                location.pathname === "/admin"
                  ? "text-yellow-300 font-semibold drop-shadow-[0_0_6px_rgba(255,255,255,0.8)]"
                  : "text-white hover:text-yellow-400"
              }`}
            >
              Admin
            </Link>
          )}

          {/* Cart Button */}
          <Link
            to="/cart"
            className="relative text-white hover:text-yellow-400 font-medium transition"
          >
            🛒 Cart
            {cart.length > 0 && (
              <span className="absolute -top-2 -right-3 bg-red-500 text-white text-xs rounded-full px-2 py-0.5 shadow">
                {cart.length}
              </span>
            )}
          </Link>

          {!user ? (
            <Link
              to="/login"
              className="px-4 py-1 rounded-md bg-yellow-400 text-black font-semibold shadow hover:bg-yellow-300 transition"
            >
              Login
            </Link>
          ) : (
            <button
              onClick={handleLogout}
              className="px-4 py-1 rounded-md bg-red-600 text-white font-semibold shadow hover:bg-red-700 transition"
            >
              Logout
            </button>
          )}
        </div>

        {/* Hamburger Button */}
        <div className="md:hidden flex items-center">
          <button
            onClick={() => setIsOpen(!isOpen)}
            aria-label="Toggle menu"
            className="relative flex flex-col justify-center items-center w-10 h-10 group"
          >
            <span
              className={`absolute block w-6 h-0.5 bg-white rounded transition-all duration-300 ${
                isOpen ? "rotate-45 translate-y-1.5" : "-translate-y-2"
              }`}
            ></span>
            <span
              className={`absolute block w-6 h-0.5 bg-white rounded transition-all duration-300 ${
                isOpen ? "opacity-0" : "opacity-100"
              }`}
            ></span>
            <span
              className={`absolute block w-6 h-0.5 bg-white rounded transition-all duration-300 ${
                isOpen ? "-rotate-45 -translate-y-1.5" : "translate-y-2"
              }`}
            ></span>
          </button>
        </div>
      </div>

      {/* Mobile Menu */}
      {isOpen && (
        <div className="md:hidden fixed top-16 left-0 w-full h-screen bg-gradient-to-b from-red-700 via-yellow-400 to-white bg-[length:300%_300%] animate-[gradientShift_10s_ease_infinite] flex flex-col items-center py-10 space-y-6">
          {links.map((l) => (
            <Link
              key={l.path}
              to={l.path}
              onClick={() => setIsOpen(false)}
              className={`text-lg transition duration-300 hover:scale-105 ${
                location.pathname === l.path
                  ? "text-red-700 font-semibold"
                  : "text-black"
              }`}
            >
              {l.name}
            </Link>
          ))}

          {isAdmin && (
            <Link
              to="/admin"
              onClick={() => setIsOpen(false)}
              className="text-lg text-red-700 font-semibold hover:scale-105 transition"
            >
              Admin
            </Link>
          )}

          <Link
            to="/cart"
            onClick={() => setIsOpen(false)}
            className="text-lg text-black font-medium hover:text-red-700 transition"
          >
            🛒 Cart ({cart.length})
          </Link>

          {!user ? (
            <Link
              to="/login"
              onClick={() => setIsOpen(false)}
              className="px-6 py-2 bg-yellow-400 text-black rounded-lg font-semibold shadow hover:bg-yellow-300 transition"
            >
              Login
            </Link>
          ) : (
            <button
              onClick={() => {
                setIsOpen(false);
                handleLogout();
              }}
              className="px-6 py-2 bg-red-600 rounded-lg font-semibold text-white shadow hover:bg-red-700 transition"
            >
              Logout
            </button>
          )}
        </div>
      )}
    </nav>
  );
}
