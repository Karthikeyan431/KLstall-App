import React from "react";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import Navbar from "./components/Navbar";
import Signup from "./pages/Signup";
import Login from "./pages/Login";
import Profile from "./pages/Profile";
import Packages from './pages/Packages';
import AdminPackages from './pages/AdminPackages';
import Cart from "./pages/Cart";
import DebugAuth from './pages/DebugAuth';
import AdminRoute from './components/AdminRoute';
import AdminPage from "./pages/AdminPage";
import Home from "./pages/Home";
import ResetPassword from './pages/ResetPassword';
import UpdatePassword from './pages/UpdatePassword';
import Dashboard from './pages/Dashboard'
import Orders from "./pages/Orders";

export default function App() {
 console.log("✅ App is rendering...");
  return (
    <BrowserRouter>
      <Navbar /> {/* Replaced old nav with Navbar component */}

      <Routes>
        <Route path="/signup" element={<Signup />} />
        <Route path="/login" element={<Login />} />
        <Route path="/" element={<Home />} />
        <Route path="/profile" element={<Profile />} />
        <Route path="/" element={<Packages />} />
        <Route path="/packages" element={<Packages />} />
        <Route path="/admin-packages" element={<AdminPackages />} />
        <Route path="/debug-auth" element={<DebugAuth />} />
        <Route path="/admin" element={	
      <AdminRoute>
        <AdminPage />
      </AdminRoute>
    } />
        <Route path="/cart" element={<Cart />} /> {/* 🛒 Cart route */}
        <Route path="/reset-password" element={<ResetPassword />} />
        <Route path="/update-password" element={<UpdatePassword />} /> {/* NEW */}
        <Route path="/dashboard" element={<Dashboard />} />
        <Route path="/orders" element={<Orders />} />
      </Routes>
    </BrowserRouter>
  );
}


